import { test, expect } from 'vitest';

test("test", () => {

    expect(2+2).toBe(4);

})
