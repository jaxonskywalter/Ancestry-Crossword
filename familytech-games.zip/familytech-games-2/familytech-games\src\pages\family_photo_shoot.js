function FamilyPhotoShootPage() {
    return <div>Family Photo Shoot</div>
}

export default FamilyPhotoShootPage;
