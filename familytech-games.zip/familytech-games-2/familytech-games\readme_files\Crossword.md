# Crossword

## About this Game

Crossword is an app that allows users to find family names based off of a hint and enter them in a connected grid structure to completion.

## App Structure

### Main Files
| File    | Info   |
|:------------ |:------ |
| [crossword.js](../src/pages/crossword.js) | Holds the main functionality including [todo] |
| [crossword.module.css](../src/styles/crossword.module.css) | Styles for the main page |

### Components
| Component    | Info   |
|:------------ |:------ |
| todo | todo |

## Known Issues
 - None at the moment

## Future Ideas
 - N/A

## Contributors
 - For questions or issues, reach out to Seth F.
