function GeneopardyPage() {
    return <div>Geneopardy</div>
}

export default GeneopardyPage;
