function WheelOfFamilyFortunePage() {
    return <div>Wheel of Family Fortune</div>
}

export default WheelOfFamilyFortunePage;