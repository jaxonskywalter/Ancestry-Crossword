import styles from '@/styles/footer_layout.module.css';

export default function FooterLayout() {

    return (
        <div className={styles.gradient}>
            <div className={styles.container}/>
        </div>
    )

}

