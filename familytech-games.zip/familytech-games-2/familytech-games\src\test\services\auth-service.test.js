import { test, expect } from 'vitest';
import AuthService from '@/services/auth-service';

test("Authtoken should be returned", () => {

    expect(2+2).toBe(4);

})
