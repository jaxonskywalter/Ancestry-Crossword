function WhosYourDaddyPage() {
  return <div>Who&apos;s Your Daddy?</div>;
}

export default WhosYourDaddyPage;
