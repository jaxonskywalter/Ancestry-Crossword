# Word Search

## About this Game

Word Search is an app that allows users to search for their ancestor's names (obtained through familysearch data) in a grid of letters.

## App Structure

### Main Files
| File    | Info   |
|:------------ |:------ |
| [word_search.js](../src/pages/word_search.js) | Holds the main functionality including [todo] |
| [word_search.module.css](../src/styles/word_search.module.css) | Styles for the main page |

### Components
| Component    | Info   |
|:------------ |:------ |
|  | . |

## Known Issues
 - None

## Future Ideas
 - N/A

## Contributors
 - For questions or issues, contact Bronze
